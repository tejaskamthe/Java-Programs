package Assignment2;

public class cmdarg2 {

	public static void main(String[] args) {
		float a,b,c;
		a=Float.parseFloat(args[0]);
		b=Float.parseFloat(args[1]);
		c=a+b;
		System.out.println("Addition Of 2 Float No :"+c);

	}

}
