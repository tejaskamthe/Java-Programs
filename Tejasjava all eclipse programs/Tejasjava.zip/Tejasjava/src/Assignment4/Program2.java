package Assignment4;

public class Program2 {

	public static void main(String[] args) {
Employee e1[]=new Employee[50];
e1[0]= new Employee("Sahil","Kumar",120.24,"02-12-2020");
e1[1]=new Employee("Saurav","yadav",1540.01,"24-10-2021");
	System.out.println(e1[0]);
	System.out.println(e1[1]);
	
	}

}
