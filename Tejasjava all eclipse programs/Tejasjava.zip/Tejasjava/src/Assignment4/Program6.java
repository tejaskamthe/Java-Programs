package Assignment4;

public class Program6 {

	public static void main(String[] args) {
		String s1="abc";
		String s2="abc";
		String s3=new String("tskp");
		String s4=new String("tskp");
		System.out.println("Its Return True Or Flase Value are Match or not  "+(s1==s2));
		System.out.println("To Comapare It's Equal or not  "+(s3.equals(s4)));
	}

}
