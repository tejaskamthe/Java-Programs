package Assignment4;

public class Program5 {

	public static void main(String[] args) {
String s=new String("T-E-J-A-S K A M T H E");
System.out.println("The Main is is: "+s);
String arr[]=s.split(" ");
System.out.println("After Spliting Blank Spaece=");
for(int i=0;i<arr.length;i++) {
	
	System.out.print(arr[i]);
}
String arr1[]=s.split("-");
System.out.print("");
	}

}
