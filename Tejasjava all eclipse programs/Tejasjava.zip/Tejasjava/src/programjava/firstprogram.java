package programjava;

public class firstprogram {

	public static void main(String args[])
	{
		System.out.println("HEllo Java..");
	}

}