package programjava;

class arithmatic{
	public static void main(String[] args)
	{
	int a=20,b=10;
	System.out.println("Addition: "+(a+b));
	System.out.println("Subtraction: "+(a-b));
	System.out.println("Multiplication: "+(a*b));
	System.out.println("Divison: "+(a/b));
	}
}