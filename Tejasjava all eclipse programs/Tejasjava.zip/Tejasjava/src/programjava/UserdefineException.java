package programjava;

public class UserdefineException extends Exception{

	public UserdefineException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserdefineException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public UserdefineException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UserdefineException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UserdefineException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		

	}

}
