/**
 * 
 */
/**
 * @author Admin
 *
 */
module Tejasjava {
	requires java.desktop;
}